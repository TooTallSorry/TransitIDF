var indexSectionsWithContent =
{
  0: "$eirst",
  1: "irst",
  2: "$ei"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "variables"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Fichiers",
  2: "Variables"
};

