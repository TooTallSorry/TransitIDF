<main>
    <h1>Plan du site</h1>
    <ul class="sitemap1">
        <li>
            <ul class="sitemap2">
                <li><a href="index.php">Accueil</a></li>
                <li><a href="tech.php">Page Technique</a>
                    <ul>
                        <li><a href="tech.php#apod">APOD</a></li>
                        <li><a href="tech.php#localisationXML">Localisation XML</a></li>
                        <li><a href="tech.php#localisationJSON">Localisation JSON</a></li>
                    </ul>
                </li>
                <li><a href="rechercheGare.php">Prochain passage d'une gare</a></li>
                <li><a href="rechercheItineraire.php">Itineraire souhaitée</a></li>
                <li><a href="stats.php">Statistique de l'utilisation du site web</a></li>
            </ul>
        </li>
    </ul>
</main>