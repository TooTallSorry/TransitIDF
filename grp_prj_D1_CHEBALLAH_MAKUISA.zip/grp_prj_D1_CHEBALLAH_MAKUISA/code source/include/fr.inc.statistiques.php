<main>
<a href="#" class="btn">
    <img src="./images/arrow.png" class="icone" alt="Fleche vers le haut"/>
</a>
    <h1>Statistiques des Recherches</h1>
    <h2>Statistiques Horaire</h2>
    <?php
    echo $gareHistogram; ?>
    <h2>Statistiques Itineraire</h2>
    <?php echo $itineraireHistogram; ?>
</main>