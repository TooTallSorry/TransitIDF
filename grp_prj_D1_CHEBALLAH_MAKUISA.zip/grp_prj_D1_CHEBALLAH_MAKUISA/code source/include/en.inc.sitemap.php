<main>
    <h1>Site Map</h1>
    <ul class="sitemap1">
        <li>
            <ul class="sitemap2">
                <li><a href="index.php">Home</a></li>
                <li><a href="tech.php">Tech Page</a>
                    <ul>
                        <li><a href="tech.php#apod">APOD</a></li>
                        <li><a href="tech.php#locationXML">Location XML</a></li>
                        <li><a href="tech.php#locationJSON">Location JSON</a></li>
                    </ul>
                </li>
                <li><a href="searchStation.php">Next departures from a station</a></li>
                <li><a href="searchItinerary.php">Desired itinerary</a></li>
                <li><a href="stats.php">Website usage statistics</a></li>
            </ul>
        </li>
    </ul>
</main>