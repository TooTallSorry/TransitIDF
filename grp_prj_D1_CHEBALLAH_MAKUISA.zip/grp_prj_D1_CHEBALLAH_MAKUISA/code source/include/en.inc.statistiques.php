<main>
    <a href="#" class="btn">
        <img src="./images/arrow.png" class="icone" alt="Up Arrow"/>
    </a>
    <h1>Search Statistics</h1>
    <h2>Timetable Statistics</h2>
    <?php echo $stationHistogram; ?>
    <h2>Itinerary Statistics</h2>
    <?php echo $itineraryHistogram; ?>
</main>